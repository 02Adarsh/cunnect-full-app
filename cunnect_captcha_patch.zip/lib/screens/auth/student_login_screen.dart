import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../services/api_client.dart';
import '../../services/app_store.dart';
import '../../theme/app_colors.dart';
import '../../widgets/common.dart';
import '../dashboard/student_dashboard_screen.dart';
import '../delivery/delivery_login_screen.dart';
import '../vendor/vendor_login_screen.dart';

/// ⭐ Original myapp flow ka exact mirror:
/// step1 UID -> step2 password+captcha -> (step3 profile complete)
/// + REGISTER -> OTP verify -> login.
class StudentLoginScreen extends StatefulWidget {
  const StudentLoginScreen({super.key});

  @override
  State<StudentLoginScreen> createState() => _StudentLoginScreenState();
}

class _StudentLoginScreenState extends State<StudentLoginScreen> {
  String _step = 'uid'; // uid | pass | reg | otp | step3
  String? _error;
  String? _info;
  bool _busy = false;
  String _captcha = '';

  final _uid = TextEditingController();
  final _password = TextEditingController();
  final _captchaC = TextEditingController();
  final _fullName = TextEditingController();
  final _regUid = TextEditingController();
  final _regEmail = TextEditingController();
  final _regPassword = TextEditingController();
  final _otpC = TextEditingController();
  final _s3Name = TextEditingController();
  final _s3Phone = TextEditingController();
  final _s3Dob = TextEditingController();
  final _s3Branch = TextEditingController();
  String _s3Gender = '';
  String _s3Year = '';
  String _s3Stay = '';
  bool _s3Consent = false;

  @override
  void dispose() {
    for (final c in [
      _uid, _password, _captchaC, _fullName, _regUid, _regEmail,
      _regPassword, _otpC, _s3Name, _s3Phone, _s3Dob, _s3Branch,
    ]) {
      c.dispose();
    }
    super.dispose();
  }

  void _go(String step) => setState(() {
        _step = step;
        _error = null;
      });

  Future<void> _next1() async {
    final store = context.read<AppStore>();
    setState(() {
      _busy = true;
      _error = null;
      _info = null;
    });
    final data = await store.authLogin1(_uid.text);
    if (!mounted) return;
    setState(() => _busy = false);
    if (data['error'] != null) {
      setState(() => _error = data['error'] as String);
      return;
    }
    if (data['registered'] == false) {
      _regUid.text = _uid.text.trim();
      setState(() => _info = 'User not registered. Please register first.');
      _go('reg');
      return;
    }
    _captcha = (data['captcha'] ?? '').toString();
    _captchaC.clear();
    _go('pass');
  }

  Future<void> _login2() async {
    final store = context.read<AppStore>();
    setState(() {
      _busy = true;
      _error = null;
    });
    final data = await store.authLogin2(
        _uid.text, _password.text, _captchaC.text.trim());
    if (!mounted) return;
    setState(() => _busy = false);
    if (data['error'] != null) {
      // naya captcha le aao (original har fail pe fresh captcha deta tha)
      final d1 = await store.authLogin1(_uid.text);
      if (!mounted) return;
      setState(() {
        _error = data['error'] as String;
        if (d1['captcha'] != null) _captcha = d1['captcha'].toString();
        _captchaC.clear();
      });
      return;
    }
    if (data['need_step3'] == true) {
      _s3Name.text = (data['name'] ?? '').toString();
      _go('step3');
    } else {
      Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const StudentDashboardScreen()));
    }
  }

  Future<void> _register() async {
    final store = context.read<AppStore>();
    setState(() {
      _busy = true;
      _error = null;
    });
    final data = await store.authRegister({
      'full_name': _fullName.text.trim(),
      'user_id': _regUid.text.trim(),
      'email': _regEmail.text.trim(),
      'password': _regPassword.text,
    });
    if (!mounted) return;
    setState(() => _busy = false);
    if (data['error'] != null) {
      setState(() => _error = data['error'] as String);
      return;
    }
    _otpC.clear();
    _go('otp');
    setState(() => _info = 'OTP has been sent to your email.');
  }

  Future<void> _verifyOtp() async {
    final store = context.read<AppStore>();
    setState(() {
      _busy = true;
      _error = null;
    });
    final data = await store.authOtpVerify(_regUid.text.trim(), _otpC.text.trim());
    if (!mounted) return;
    setState(() => _busy = false);
    if (data['error'] != null) {
      setState(() => _error = data['error'] as String);
      return;
    }
    _uid.text = _regUid.text.trim();
    _go('uid');
    setState(() => _info = 'Registration successful! You can now login.');
  }

  Future<void> _resendOtp() async {
    final store = context.read<AppStore>();
    final data = await store.authResendOtp(_regUid.text.trim());
    if (!mounted) return;
    setState(() => _info = data['error'] != null
        ? data['error'] as String
        : 'New OTP has been sent.');
  }

  Future<void> _completeProfile() async {
    final store = context.read<AppStore>();
    setState(() {
      _busy = true;
      _error = null;
    });
    final data = await store.authCompleteProfile({
      'full_name': _s3Name.text.trim(),
      'phone': _s3Phone.text.trim(),
      'dob': _s3Dob.text.trim(),
      'gender': _s3Gender,
      'branch': _s3Branch.text.trim(),
      'year': _s3Year,
      'stay_type': _s3Stay,
      'consent': _s3Consent,
    });
    if (!mounted) return;
    setState(() => _busy = false);
    if (data['error'] != null) {
      setState(() => _error = data['error'] as String);
      return;
    }
    Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const StudentDashboardScreen()));
  }

  Widget _field(TextEditingController c, String hint, IconData icon,
      {bool obscure = false, TextInputType? keyboard, bool caps = false}) {
    return TextField(
      controller: c,
      obscureText: obscure,
      keyboardType: keyboard,
      textCapitalization:
          caps ? TextCapitalization.characters : TextCapitalization.none,
      autocorrect: false,
      style: const TextStyle(fontSize: 13),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: AppColors.placeholder, fontSize: 13),
        prefixIcon: Icon(icon, size: 16, color: AppColors.muted),
        filled: true,
        fillColor: const Color(0xFF0C0C0C),
        contentPadding: const EdgeInsets.symmetric(horizontal: 13),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: Color(0xFF363636)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: AppColors.red),
        ),
      ),
    );
  }

  Widget _button(String label, VoidCallback onTap) => SizedBox(
        width: double.infinity,
        height: 47,
        child: ElevatedButton(
          onPressed: _busy ? null : onTap,
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.red,
            foregroundColor: Colors.white,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800),
          ),
          child: _busy
              ? const SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                      color: Colors.white, strokeWidth: 2))
              : Text(label),
        ),
      );

  Widget _link(String label, VoidCallback onTap) => InkWell(
        onTap: onTap,
        child: Text(label,
            style: const TextStyle(
                color: Color(0xFFFF9CA5), fontSize: 11.5, fontWeight: FontWeight.w700)),
      );

  String get _heading {
    switch (_step) {
      case 'pass':
        return 'PASSWORD';
      case 'reg':
        return 'REGISTRATION';
      case 'otp':
        return 'OTP VERIFICATION';
      case 'step3':
        return 'COMPLETE PROFILE';
      default:
        return 'LOGIN';
    }
  }

  String get _sub {
    switch (_step) {
      case 'pass':
        return 'Enter password + captcha for ${_uid.text.trim()}';
      case 'reg':
        return 'Official @culkomail.in email se register karo';
      case 'otp':
        return 'Email pe aaya 6-digit OTP daalo';
      case 'step3':
        return 'Ek baar — profile details zaroori hain';
      default:
        return 'Enter your UID to continue';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.black,
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment(0.85, -0.8),
            radius: 0.6,
            colors: [Color(0x38F10B1D), Colors.transparent],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 390),
                child: Container(
                  padding: const EdgeInsets.fromLTRB(25, 34, 25, 25),
                  decoration: BoxDecoration(
                    color: const Color(0xED121212),
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(color: const Color(0xFF2B2B2B)),
                    boxShadow: [
                      BoxShadow(
                          color: Colors.black.withOpacity(.6),
                          blurRadius: 55,
                          offset: const Offset(0, 18)),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      const CunnectWordmark(fontSize: 42),
                      const SizedBox(height: 10),
                      const Text('YOUR CAMPUS. CONNECTED.',
                          style: TextStyle(
                              color: AppColors.gold,
                              fontSize: 9,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 2)),
                      const SizedBox(height: 26),
                      Text(_heading,
                          style: const TextStyle(
                              fontSize: 24, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 7),
                      Text(_sub,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                              color: AppColors.muted, fontSize: 12.5)),
                      const SizedBox(height: 20),
                      if (_error != null)
                        Container(
                          width: double.infinity,
                          margin: const EdgeInsets.only(bottom: 14),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 11, vertical: 10),
                          decoration: BoxDecoration(
                            color: const Color(0x1AF10B1D),
                            borderRadius: BorderRadius.circular(9),
                            border: Border.all(color: const Color(0x80F10B1D)),
                          ),
                          child: Text(_error!,
                              style: const TextStyle(
                                  color: Color(0xFFFFABB2),
                                  fontSize: 12,
                                  height: 1.4)),
                        ),
                      if (_info != null)
                        Container(
                          width: double.infinity,
                          margin: const EdgeInsets.only(bottom: 14),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 11, vertical: 10),
                          decoration: BoxDecoration(
                            color: const Color(0x142ECC71),
                            borderRadius: BorderRadius.circular(9),
                            border: Border.all(color: const Color(0x662ECC71)),
                          ),
                          child: Text(_info!,
                              style: const TextStyle(
                                  color: Color(0xFF9BE8B8),
                                  fontSize: 12,
                                  height: 1.4)),
                        ),
                      ..._stepBody(),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  List<Widget> _stepBody() {
    switch (_step) {
      case 'pass':
        return [
          Container(
            width: double.infinity,
            margin: const EdgeInsets.only(bottom: 14),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: const Color(0xFF0C0C0C),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: const Color(0xFF363636)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('CAPTCHA',
                    style: TextStyle(
                        color: AppColors.muted,
                        fontSize: 9,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1.5)),
                Text(_captcha,
                    style: const TextStyle(
                        fontFamily: 'monospace',
                        fontSize: 20,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 6,
                        color: AppColors.gold)),
              ],
            ),
          ),
          _field(_password, 'Enter password', Icons.lock_outline, obscure: true),
          const SizedBox(height: 14),
          _field(_captchaC, 'Type captcha', Icons.shield_outlined, caps: true),
          const SizedBox(height: 20),
          _button('LOGIN', _login2),
          const SizedBox(height: 14),
          _link('← Back', () => _go('uid')),
          const SizedBox(height: 14),
          _serverChip(),
        ];
      case 'reg':
        return [
          _field(_fullName, 'Full name', Icons.person_outline),
          const SizedBox(height: 14),
          _field(_regUid, 'User ID (e.g. 25lbcs3056)', Icons.badge_outlined),
          const SizedBox(height: 14),
          _field(_regEmail, 'Email (@culkomail.in)', Icons.mail_outline,
              keyboard: TextInputType.emailAddress),
          const SizedBox(height: 14),
          _field(_regPassword, 'Set password', Icons.lock_outline, obscure: true),
          const SizedBox(height: 20),
          _button('SEND OTP', _register),
          const SizedBox(height: 14),
          _link('← Back to login', () => _go('uid')),
          const SizedBox(height: 14),
          _serverChip(),
        ];
      case 'otp':
        return [
          _field(_otpC, '6-digit OTP', Icons.pin_outlined,
              keyboard: TextInputType.number),
          const SizedBox(height: 20),
          _button('VERIFY OTP', _verifyOtp),
          const SizedBox(height: 14),
          _link('Resend OTP', _resendOtp),
          const SizedBox(height: 14),
          _serverChip(),
        ];
      case 'step3':
        return [
          _field(_s3Name, 'Full name', Icons.person_outline),
          const SizedBox(height: 14),
          _field(_s3Phone, 'Phone number', Icons.phone_outlined,
              keyboard: TextInputType.phone),
          const SizedBox(height: 14),
          _field(_s3Dob, 'Date of birth (YYYY-MM-DD)', Icons.cake_outlined),
          const SizedBox(height: 14),
          Row(children: [
            Expanded(
              child: _dropdown('Gender', _s3Gender,
                  ['', 'Male', 'Female', 'Other'], (v) => _s3Gender = v),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _dropdown('Year', _s3Year,
                  ['', '1', '2', '3', '4', '5'], (v) => _s3Year = v),
            ),
          ]),
          const SizedBox(height: 14),
          _field(_s3Branch, 'Branch (e.g. BCS)', Icons.school_outlined),
          const SizedBox(height: 14),
          _dropdown('Stay type', _s3Stay,
              ['', 'Day Scholar', 'Hosteller'], (v) => _s3Stay = v),
          const SizedBox(height: 12),
          Row(
            children: [
              Checkbox(
                value: _s3Consent,
                activeColor: AppColors.red,
                onChanged: (v) => setState(() => _s3Consent = v ?? false),
              ),
              const Expanded(
                child: Text('I consent to campus profile use.',
                    style: TextStyle(color: AppColors.muted, fontSize: 11)),
              ),
            ],
          ),
          const SizedBox(height: 8),
          _button('SAVE & CONTINUE', _completeProfile),
        ];
      default:
        return [
          _field(_uid, 'Enter UID', Icons.person_outline),
          const SizedBox(height: 20),
          _button('NEXT', _next1),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 18),
            child: Row(
              children: [
                const Expanded(child: Divider(color: Color(0xFF333333))),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: Text('OR',
                      style: TextStyle(
                          color: AppColors.muted.withOpacity(.7), fontSize: 11)),
                ),
                const Expanded(child: Divider(color: Color(0xFF333333))),
              ],
            ),
          ),
          InkWell(
            onTap: () => _go('reg'),
            borderRadius: BorderRadius.circular(12),
            child: Container(
              width: double.infinity,
              height: 46,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0x99D4C7A3)),
              ),
              child: const Text('CLICK HERE FOR REGISTRATION',
                  style: TextStyle(
                      color: AppColors.gold,
                      fontSize: 11.5,
                      fontWeight: FontWeight.w800)),
            ),
          ),
          const SizedBox(height: 16),
          _serverChip(),
          const SizedBox(height: 18),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _portalLink('🏪 Vendor Portal', () {
                Navigator.of(context).push(MaterialPageRoute(
                    builder: (_) => const VendorLoginScreen()));
              }),
              const SizedBox(width: 18),
              _portalLink('🛵 Delivery', () {
                Navigator.of(context).push(MaterialPageRoute(
                    builder: (_) => const DeliveryLoginScreen()));
              }),
            ],
          ),
        ];
    }
  }

  Widget _dropdown(String label, String value, List<String> options,
      ValueChanged<String> onCh) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
        color: const Color(0xFF0C0C0C),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: const Color(0xFF363636)),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: value,
          isExpanded: true,
          dropdownColor: const Color(0xFF141414),
          style: const TextStyle(color: Colors.white, fontSize: 12.5),
          hint: Text(label,
              style: const TextStyle(color: AppColors.placeholder, fontSize: 12.5)),
          items: [
            for (final o in options)
              DropdownMenuItem(value: o, child: Text(o.isEmpty ? label : o)),
          ],
          onChanged: (v) => setState(() => onCh(v ?? '')),
        ),
      ),
    );
  }

  Widget _serverChip() => InkWell(
        onTap: _showServerSettings,
        borderRadius: BorderRadius.circular(8),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color: const Color(0xFF101010),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: const Color(0xFF2B2B2B)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('⚙ ',
                  style: TextStyle(color: Color(0xFF8F8F8F), fontSize: 10.5)),
              Flexible(
                child: Text('Server: ${ApiConfig.baseUrl}',
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Color(0xFF8F8F8F), fontSize: 10.5)),
              ),
            ],
          ),
        ),
      );

  Widget _portalLink(String label, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Text(label,
          style: const TextStyle(
              color: Color(0xFFFF9CA5), fontSize: 11, fontWeight: FontWeight.w700)),
    );
  }

  void _showServerSettings() {
    final controller = TextEditingController(text: ApiConfig.baseUrl);
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: const Color(0xFF141414),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Server URL',
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
        content: TextField(
          controller: controller,
          style: const TextStyle(fontSize: 13),
          decoration: InputDecoration(
            hintText: 'http://10.0.2.2:8000',
            filled: true,
            fillColor: const Color(0xFF1B1B1B),
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: const BorderSide(color: Color(0xFF303030))),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('Cancel', style: TextStyle(color: AppColors.muted)),
          ),
          TextButton(
            onPressed: () {
              final value = controller.text.trim();
              if (value.isNotEmpty) ApiConfig.setBaseUrl(value);
              Navigator.of(dialogContext).pop();
              setState(() {});
            },
            child: const Text('Save',
                style: TextStyle(color: AppColors.red, fontWeight: FontWeight.w800)),
          ),
        ],
      ),
    );
  }
}
